#ifndef  BUTIL_CONFIG_H
#define  BUTIL_CONFIG_H

/* #undef BRPC_WITH_GLOG */

#endif  // BUTIL_CONFIG_H
